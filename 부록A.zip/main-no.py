#code for y
#f0= 약 110Hz
#복사할 주파수 대역 930-1150Hz 중 에너지 낮은 곳 기준하여  주파수대를 220Hz 만큼 복사해서 늘릴것임.

import pyaudio
import struct
import numpy as np
from scipy.io import wavfile
import matplotlib.pyplot as plt
import wave
from scipy.signal import lfilter, freqz

exp_num=input('experiment num')

sample_rate=11000
chunk=1000
swidth=2

audio = pyaudio.PyAudio()

stream_in = audio.open(format=pyaudio.paInt16,
                       channels=1,
                       rate=sample_rate,
                       input=True,
                       frames_per_buffer=chunk)

stream_out = audio.open(format=pyaudio.paInt16,
                        channels=1,
                        rate=sample_rate,
                        output=True)

def fft_regenerator(fft_data):
    #진짜 주파수 찾기
    ten_peak=np.max(fft_data[95:105])
    eleven_peak=np.max(fft_data[105:115])
    if eleven_peak>ten_peak:
        rd_start=np.argmin(fft_data[90:100])+90
        layer1=fft_data[0:rd_start]
        layer2=fft_data[rd_start:rd_start+10]
        layer3=fft_data[rd_start+10:480]
        new_fft1=np.concatenate((layer1,layer2,layer2,layer2,layer3))
    if eleven_peak<ten_peak:
        rd_start=np.argmin(fft_data[100:110])+100
        layer1=fft_data[0:rd_start]
        layer2=fft_data[rd_start:rd_start+10]
        layer3=fft_data[rd_start+10:480]
        new_fft1=np.concatenate((layer1,layer2,layer2,layer2,layer3))

    result=np.concatenate((new_fft1,new_fft1[::-1]))
    print(len(result))
    return result

input_data=[]
filtered_data=[]
peak_list=[]
ffts=[]
i=0 
shift=1
f0_=110
ex_time=120
time=0
print("y2sh")

while time < ex_time*11:
    time += 1
    data = stream_in.read(chunk, exception_on_overflow=False)
    input_buffer = np.array(struct.unpack(f"{len(data)//swidth}h", data))
    input_data.append(input_buffer)
    
    X = np.fft.fft(input_buffer)
    freqs = np.fft.fftfreq(len(input_buffer), 1/sample_rate)
    print(len(freqs))
    filtered_X=fft_regenerator(X)
    filtered_buffer=np.fft.ifft(X).real
    filtered_data.append(filtered_buffer)
    data_out = filtered_buffer.astype(np.int16)
    data_out = struct.pack(f"{len(data_out)}h", *data_out)
    stream_out.write(data_out)

stream_in.stop_stream()
stream_in.close()
stream_out.stop_stream()
stream_out.close()
audio.terminate()

print("experiment end")

saved_data = np.concatenate(input_data)
filtered_data = np.concatenate(filtered_data)
saved_data = saved_data.astype(np.int16)
filtered_data = filtered_data.astype(np.int16)

wavfile.write('raw'+str(exp_num)+'no_dist.wav', sample_rate, saved_data)
wavfile.write('filtered'+str(exp_num)+'no_dist.wav', sample_rate, filtered_data)



